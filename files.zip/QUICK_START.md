# 🚀 Quick Start Guide - GitHub + Streamlit Deployment

## 📋 What You'll Need (5 minutes setup)

1. **GitHub Account** (free) - [github.com](https://github.com)
2. **Supabase Account** (free) - [supabase.com](https://supabase.com)
3. **Streamlit Cloud Account** (free) - [share.streamlit.io](https://share.streamlit.io)

---

## 🎯 Step-by-Step Deployment

### ✅ STEP 1: Setup GitHub (2 minutes)

1. **Create a new repository:**
   - Go to [github.com/new](https://github.com/new)
   - Name it: `sustainability-scanner`
   - Make it **Public**
   - Don't add README (we already have one)
   - Click **Create repository**

2. **Upload files to GitHub:**
   
   **Option A - Upload via web:**
   - Click "uploading an existing file"
   - Drag and drop all these files:
     - `streamlit_app.py`
     - `requirements.txt`
     - `.streamlit/config.toml`
     - `.gitignore`
     - `STREAMLIT_README.md` (rename to `README.md`)
     - `.env.example`
     - `supabase-schema.sql`
   - Click "Commit changes"

   **Option B - Push via command line:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/sustainability-scanner.git
   git push -u origin main
   ```

---

### ✅ STEP 2: Setup Supabase Database (3 minutes)

1. **Create Supabase project:**
   - Go to [supabase.com](https://supabase.com)
   - Click "New Project"
   - Name: `sustainability-scanner`
   - Choose a password (save it!)
   - Choose region closest to you
   - Wait ~2 minutes for setup

2. **Create database table:**
   - Go to **SQL Editor** (left sidebar)
   - Click "New Query"
   - Copy contents from `supabase-schema.sql` file
   - Paste and click **Run**
   - You should see "Success. No rows returned"

3. **Get your credentials:**
   - Go to **Settings** → **API**
   - Copy these two values:
     - ✅ `Project URL` (looks like: `https://abcdefgh.supabase.co`)
     - ✅ `anon` `public` key (long string starting with `eyJ...`)
   - Keep these safe - you'll need them next!

---

### ✅ STEP 3: Deploy to Streamlit Cloud (2 minutes)

1. **Connect to Streamlit:**
   - Go to [share.streamlit.io](https://share.streamlit.io)
   - Click "New app"
   - Sign in with GitHub
   - Authorize Streamlit

2. **Configure deployment:**
   - Repository: `YOUR_USERNAME/sustainability-scanner`
   - Branch: `main`
   - Main file path: `streamlit_app.py`

3. **Add secrets:**
   - Click "Advanced settings"
   - In the **Secrets** box, paste:
   
   ```toml
   SUPABASE_URL = "https://your-project.supabase.co"
   SUPABASE_KEY = "your-anon-key-here"
   ```
   
   - Replace with YOUR actual Supabase credentials from Step 2
   - Click "Deploy"!

4. **Wait for deployment:**
   - Takes ~2 minutes
   - You'll get a URL like: `https://your-app.streamlit.app`

---

## 🎉 Done! Test Your App

1. **Open your app URL**
2. **Upload a test image** (any product photo)
3. **Click "Analyze Sustainability"**
4. **Watch the magic happen!** ✨

---

## 📱 Access from Mobile

Your app is now live on the internet!

- **From ANY phone/tablet:**
  1. Open browser
  2. Go to your Streamlit app URL
  3. Use your camera to take photos
  4. Analyze products instantly!

- **Share with friends:**
  - Just send them your app URL
  - No installation needed
  - Works on any device!

---

## 🛠️ Update Your App

Made changes? Just push to GitHub:

```bash
git add .
git commit -m "Updated features"
git push
```

Streamlit will automatically redeploy! 🚀

---

## 🆘 Troubleshooting

### "Cannot connect to Supabase"
✅ Check your secrets in Streamlit settings
✅ Make sure you copied the correct URL and key
✅ URL should include `https://`

### "No module named 'streamlit'"
✅ Make sure `requirements.txt` is in your repo
✅ Try redeploying the app

### "Database query failed"
✅ Check you ran the SQL schema in Supabase
✅ Verify RLS policies are enabled

### App is slow
✅ Normal on first load (Streamlit "wakes up")
✅ Subsequent loads are faster
✅ Consider upgrading to paid tier for instant load

---

## 💡 Pro Tips

1. **Custom Domain:**
   - Streamlit Cloud allows custom domains
   - Go to Settings → General → Custom domain

2. **Analytics:**
   - Add Google Analytics to track usage
   - Monitor in Streamlit Cloud dashboard

3. **Security:**
   - Never commit `.env` file to GitHub
   - Always use Streamlit secrets for credentials
   - Rotate keys regularly

4. **Performance:**
   - Optimize images before upload
   - Use image compression
   - Limit to 5MB per image

---

## 🎯 Next Steps

1. ⭐ Star your repository
2. 📣 Share your app with friends
3. 🎨 Customize the colors and styling
4. 📊 Add more analytics features
5. 🌍 Help make the world more sustainable!

---

## 📧 Need Help?

- 📖 Check the full README.md
- 💬 Open an issue on GitHub
- 🔍 Search Streamlit forums

---

**Congratulations! 🎊 Your Sustainability Scanner is now live!**

Share your app URL: `https://your-app.streamlit.app`
