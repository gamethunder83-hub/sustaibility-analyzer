import streamlit as st
import requests
import json
from PIL import Image
import io
import base64
from datetime import datetime
from supabase import create_client, Client
import os

# Page configuration
st.set_page_config(
    page_title="🌱 Sustainability Scanner",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for animations and styling
st.markdown("""
<style>
    .main {
        background: linear-gradient(135deg, #f0fdf4 0%, #dbeafe 100%);
    }
    
    .stButton>button {
        width: 100%;
        background-color: #16a34a;
        color: white;
        font-weight: bold;
        padding: 0.75rem;
        border-radius: 0.5rem;
        border: none;
        font-size: 1.1rem;
    }
    
    .stButton>button:hover {
        background-color: #15803d;
    }
    
    .sustainable-card {
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        border-left: 5px solid #22c55e;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        animation: fadeIn 0.5s ease-in;
    }
    
    .not-sustainable-card {
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
        border-left: 5px solid #ef4444;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes glow-green {
        0%, 100% { box-shadow: 0 0 10px rgba(34, 197, 94, 0.5); }
        50% { box-shadow: 0 0 30px rgba(34, 197, 94, 1); }
    }
    
    @keyframes glow-red {
        0%, 100% { box-shadow: 0 0 10px rgba(239, 68, 68, 0.5); }
        50% { box-shadow: 0 0 30px rgba(239, 68, 68, 1); }
    }
    
    .scanning-green {
        animation: glow-green 0.8s ease-in-out;
        border: 3px solid #22c55e;
    }
    
    .scanning-red {
        animation: glow-red 0.8s ease-in-out;
        border: 3px solid #ef4444;
    }
    
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 0.75rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    
    .score-badge {
        display: inline-block;
        padding: 0.5rem 1rem;
        border-radius: 2rem;
        font-weight: bold;
        font-size: 0.9rem;
    }
    
    .badge-sustainable {
        background-color: #dcfce7;
        color: #166534;
    }
    
    .badge-not-sustainable {
        background-color: #fee2e2;
        color: #991b1b;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'scan_results' not in st.session_state:
    st.session_state.scan_results = []
if 'scan_history' not in st.session_state:
    st.session_state.scan_history = []
if 'current_summary' not in st.session_state:
    st.session_state.current_summary = None

# Initialize Supabase client
@st.cache_resource
def init_supabase():
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_KEY")
    
    if supabase_url and supabase_key:
        return create_client(supabase_url, supabase_key)
    return None

supabase = init_supabase()

# Function to analyze image with Claude API
def analyze_image_with_claude(image_bytes):
    """Analyze image using Claude API through Anthropic"""
    try:
        # Convert image to base64
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        # Determine image type
        image = Image.open(io.BytesIO(image_bytes))
        img_format = image.format.lower()
        if img_format == 'jpg':
            img_format = 'jpeg'
        media_type = f"image/{img_format}"
        
        # Call Claude API
        api_url = "https://api.anthropic.com/v1/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": os.getenv("ANTHROPIC_API_KEY", ""),
        }
        
        payload = {
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": base64_image,
                            },
                        },
                        {
                            "type": "text",
                            "text": """Analyze this image and identify up to 10 distinct objects/products visible. For each object, determine if it's sustainable or not sustainable based on:
- Material composition (recyclable, biodegradable, renewable)
- Environmental impact
- Durability and lifecycle
- Production process

Respond ONLY with a JSON array, no other text or markdown:
[
  {"name": "object name", "sustainable": true/false, "reason": "brief explanation"},
  ...
]"""
                        }
                    ],
                },
            ],
        }
        
        response = requests.post(api_url, headers=headers, json=payload)
        
        if response.status_code != 200:
            return None, f"API Error: {response.status_code}"
        
        data = response.json()
        
        if not data.get('content') or not data['content'][0]:
            return None, "Invalid API response"
        
        text = data['content'][0]['text']
        
        # Extract JSON from response
        import re
        json_match = re.search(r'\[[\s\S]*\]', text)
        
        if not json_match:
            return None, "Could not parse API response"
        
        objects = json.loads(json_match.group(0))
        return objects, None
        
    except Exception as e:
        return None, f"Error: {str(e)}"

# Function to save scan to Supabase
def save_scan_to_db(objects, summary):
    """Save scan results to Supabase"""
    if not supabase:
        return None
    
    try:
        scan_data = {
            "timestamp": datetime.now().isoformat(),
            "objects_detected": objects,
            "total_objects": summary['total'],
            "sustainable_count": summary['sustainable'],
            "unsustainable_count": summary['unsustainable'],
            "sustainability_score": summary['score'],
            "overall_sustainable": summary['overall_sustainable']
        }
        
        result = supabase.table('scans').insert(scan_data).execute()
        return result.data[0]['id'] if result.data else None
    except Exception as e:
        st.error(f"Database error: {str(e)}")
        return None

# Function to load scan history
def load_scan_history():
    """Load recent scans from Supabase"""
    if not supabase:
        return []
    
    try:
        result = supabase.table('scans').select("*").order('timestamp', desc=True).limit(20).execute()
        return result.data if result.data else []
    except Exception as e:
        st.error(f"Error loading history: {str(e)}")
        return []

# Main app header
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    st.title("🌱 Sustainability Scanner")
    st.markdown("### AI-Powered Product Sustainability Analysis")

st.markdown("---")

# Color legend
col1, col2 = st.columns(2)
with col1:
    st.markdown("🟢 **Green = Sustainable**")
with col2:
    st.markdown("🔴 **Red = Not Sustainable**")

st.markdown("---")

# Main layout
left_col, right_col = st.columns([2, 1])

with left_col:
    st.subheader("📤 Upload Product Image")
    
    # File uploader with camera option (mobile-friendly)
    uploaded_file = st.file_uploader(
        "Take a photo or choose from gallery",
        type=['png', 'jpg', 'jpeg', 'webp'],
        help="Upload a clear image of products for analysis"
    )
    
    if uploaded_file is not None:
        # Display uploaded image
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_container_width=True)
        
        # Analyze button
        if st.button("🔍 Analyze Sustainability", type="primary"):
            with st.spinner("🤖 Analyzing image with AI..."):
                # Get image bytes
                image_bytes = uploaded_file.getvalue()
                
                # Analyze with Claude
                objects, error = analyze_image_with_claude(image_bytes)
                
                if error:
                    st.error(f"❌ {error}")
                elif objects:
                    st.session_state.scan_results = objects
                    
                    # Calculate summary
                    total = len(objects)
                    sustainable = sum(1 for obj in objects if obj['sustainable'])
                    unsustainable = total - sustainable
                    score = round((sustainable / total) * 100) if total > 0 else 0
                    overall_sustainable = score >= 50
                    
                    summary = {
                        'total': total,
                        'sustainable': sustainable,
                        'unsustainable': unsustainable,
                        'score': score,
                        'overall_sustainable': overall_sustainable
                    }
                    
                    st.session_state.current_summary = summary
                    
                    # Save to database
                    scan_id = save_scan_to_db(objects, summary)
                    if scan_id:
                        st.success(f"✅ Scan saved to database! ID: {scan_id}")
                    
                    # Reload history
                    st.session_state.scan_history = load_scan_history()
                    
                    st.rerun()
    
    # Display results
    if st.session_state.scan_results:
        st.markdown("---")
        st.subheader(f"🔍 Detected Objects ({len(st.session_state.scan_results)})")
        
        for idx, obj in enumerate(st.session_state.scan_results):
            if obj['sustainable']:
                st.markdown(f"""
                <div class="sustainable-card">
                    <h4>✅ {obj['name']}</h4>
                    <p>{obj['reason']}</p>
                    <span class="score-badge badge-sustainable">✓ SUSTAINABLE</span>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="not-sustainable-card">
                    <h4>❌ {obj['name']}</h4>
                    <p>{obj['reason']}</p>
                    <span class="score-badge badge-not-sustainable">✗ NOT SUSTAINABLE</span>
                </div>
                """, unsafe_allow_html=True)

with right_col:
    # Summary section
    if st.session_state.current_summary:
        st.subheader("📊 Summary")
        summary = st.session_state.current_summary
        
        # Sustainable count
        st.markdown(f"""
        <div class="metric-card" style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);">
            <h1 style="color: #22c55e; margin: 0;">{summary['sustainable']}</h1>
            <p style="margin: 0;">Sustainable</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Unsustainable count
        st.markdown(f"""
        <div class="metric-card" style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);">
            <h1 style="color: #ef4444; margin: 0;">{summary['unsustainable']}</h1>
            <p style="margin: 0;">Not Sustainable</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Overall score
        st.markdown(f"""
        <div class="metric-card" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);">
            <h1 style="color: #3b82f6; margin: 0;">{summary['score']}%</h1>
            <p style="margin: 0;">Overall Score</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Overall verdict
        if summary['overall_sustainable']:
            st.success("### ✅ Overall: SUSTAINABLE")
        else:
            st.error("### ⚠️ Overall: NOT SUSTAINABLE")
    
    # Scan history
    st.markdown("---")
    st.subheader("📜 Recent Scans")
    
    if st.button("🔄 Refresh History"):
        st.session_state.scan_history = load_scan_history()
        st.rerun()
    
    if supabase:
        if not st.session_state.scan_history:
            st.session_state.scan_history = load_scan_history()
        
        if st.session_state.scan_history:
            for scan in st.session_state.scan_history[:10]:
                score = scan.get('sustainability_score', 0)
                total = scan.get('total_objects', 0)
                timestamp = datetime.fromisoformat(scan['timestamp']).strftime("%b %d, %H:%M")
                
                badge_class = "badge-sustainable" if scan.get('overall_sustainable') else "badge-not-sustainable"
                
                st.markdown(f"""
                <div style="background: white; padding: 0.75rem; border-radius: 0.5rem; margin: 0.5rem 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong>{total} objects</strong><br>
                            <small style="color: #6b7280;">{timestamp}</small>
                        </div>
                        <span class="score-badge {badge_class}">{score}%</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("No scan history yet")
    else:
        st.warning("⚠️ Supabase not configured. History unavailable.")

# Sidebar with instructions
with st.sidebar:
    st.header("ℹ️ How to Use")
    st.markdown("""
    1. **📱 Upload/Capture** a product image
    2. **🔍 Click Analyze** to scan
    3. **👀 Watch** green/red indicators
    4. **📊 View** sustainability scores
    5. **📜 Check** scan history
    
    ---
    
    ### 🎨 Color Guide
    - 🟢 **Green** = Sustainable
    - 🔴 **Red** = Not Sustainable
    
    ---
    
    ### 🔑 Setup Required
    Set these secrets in Streamlit Cloud:
    - `SUPABASE_URL`
    - `SUPABASE_KEY`
    - `ANTHROPIC_API_KEY` (optional)
    """)
    
    # Configuration status
    st.markdown("---")
    st.subheader("⚙️ Configuration")
    
    if os.getenv("SUPABASE_URL"):
        st.success("✅ Supabase connected")
    else:
        st.error("❌ Supabase not configured")
    
    if os.getenv("ANTHROPIC_API_KEY"):
        st.success("✅ Anthropic API configured")
    else:
        st.warning("⚠️ Using demo mode")

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6b7280; padding: 1rem;">
    <p>🌱 Sustainability Scanner | Powered by AI</p>
    <p style="font-size: 0.8rem;">Analyze products for environmental impact</p>
</div>
""", unsafe_allow_html=True)
