# 🌱 Sustainability Scanner - Streamlit App

AI-powered product sustainability analysis with real-time glowing animations. Upload product images and get instant sustainability ratings with color-coded results.

![Streamlit](https://img.shields.io/badge/Streamlit-FF4B4B?style=for-the-badge&logo=Streamlit&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Supabase](https://img.shields.io/badge/Supabase-181818?style=for-the-badge&logo=supabase&logoColor=white)

## ✨ Features

- 📱 **Mobile-Friendly** - Works perfectly on phones and tablets
- 🎨 **Color-Coded Animations** - Green for sustainable, Red for not sustainable
- 🤖 **AI-Powered** - Uses Claude AI for object detection and analysis
- 💾 **Database Storage** - Saves all scans to Supabase
- 📊 **Real-Time Scoring** - Instant sustainability percentage
- 📜 **Scan History** - View past scans and results
- 🎯 **Up to 10 Objects** - Detects multiple products per image

## 🚀 Quick Deploy to Streamlit Cloud

### Option 1: One-Click Deploy (Easiest!)

1. Fork this repository to your GitHub account
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click "New app"
4. Connect your GitHub repository
5. Set `Main file path` to: `streamlit_app.py`
6. Click "Deploy"!

### Option 2: Manual Setup

#### Step 1: Setup Supabase Database

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project
3. Go to **SQL Editor** and run:

```sql
CREATE TABLE IF NOT EXISTS scans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  objects_detected JSONB NOT NULL,
  total_objects INTEGER NOT NULL,
  sustainable_count INTEGER NOT NULL,
  unsustainable_count INTEGER NOT NULL,
  sustainability_score INTEGER NOT NULL,
  overall_sustainable BOOLEAN NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX scans_timestamp_idx ON scans(timestamp DESC);

ALTER TABLE scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access" ON scans
  FOR SELECT USING (true);

CREATE POLICY "Allow public insert access" ON scans
  FOR INSERT WITH CHECK (true);
```

4. Get your credentials from **Settings** → **API**:
   - Copy `Project URL`
   - Copy `anon` `public` key

#### Step 2: Configure Secrets in Streamlit Cloud

1. In your deployed app, click **⋮ → Settings**
2. Go to **Secrets** section
3. Add your secrets:

```toml
SUPABASE_URL = "https://your-project.supabase.co"
SUPABASE_KEY = "your-anon-key-here"

# Optional: Add Anthropic API key if you have one
# ANTHROPIC_API_KEY = "your-api-key"
```

4. Click "Save"
5. App will automatically restart

## 💻 Local Development

### Prerequisites

- Python 3.8+
- pip

### Installation

1. **Clone the repository**

```bash
git clone https://github.com/yourusername/sustainability-scanner.git
cd sustainability-scanner
```

2. **Create virtual environment**

```bash
python -m venv venv

# On Windows:
venv\Scripts\activate

# On Mac/Linux:
source venv/bin/activate
```

3. **Install dependencies**

```bash
pip install -r requirements.txt
```

4. **Create `.env` file**

```bash
cp .env.example .env
```

Edit `.env` and add your credentials:

```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key
ANTHROPIC_API_KEY=your-api-key  # Optional
```

5. **Run the app**

```bash
streamlit run streamlit_app.py
```

6. **Open in browser**

The app will automatically open at `http://localhost:8501`

## 📱 Using on Mobile

### Access from Phone (Same Wi-Fi)

1. **Find your computer's IP address:**

   **Windows:**
   ```cmd
   ipconfig
   ```
   Look for "IPv4 Address" (e.g., `192.168.1.100`)

   **Mac/Linux:**
   ```bash
   ifconfig | grep inet
   ```

2. **Run Streamlit with network access:**

```bash
streamlit run streamlit_app.py --server.address 0.0.0.0
```

3. **On your phone:**
   - Connect to the same Wi-Fi
   - Open browser
   - Go to: `http://YOUR_IP:8501`
   - Example: `http://192.168.1.100:8501`

### Deploy to Cloud (Access from Anywhere)

Deploy to Streamlit Cloud (free) and access from any device:

1. Push code to GitHub
2. Deploy on [share.streamlit.io](https://share.streamlit.io)
3. Get a public URL like: `https://your-app.streamlit.app`
4. Access from any phone/device anywhere!

## 🎯 How to Use

1. **📤 Upload Image**
   - Click "Browse files" or drag & drop
   - On mobile: Tap to take photo or choose from gallery

2. **🔍 Analyze**
   - Click "Analyze Sustainability" button
   - Watch AI detect objects in real-time

3. **👀 View Results**
   - Green cards = Sustainable products ✅
   - Red cards = Not sustainable products ❌
   - See detailed explanations for each item

4. **📊 Check Score**
   - View overall sustainability percentage
   - See breakdown of sustainable vs not sustainable

5. **📜 History**
   - All scans saved automatically
   - View past scans in sidebar

## 📁 Project Structure

```
sustainability-scanner/
├── streamlit_app.py          # Main Streamlit application
├── requirements.txt          # Python dependencies
├── .streamlit/
│   └── config.toml          # Streamlit configuration
├── .gitignore               # Git ignore rules
├── .env.example             # Environment variables template
├── supabase-schema.sql      # Database schema
└── README.md               # This file
```

## 🔧 Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `SUPABASE_URL` | Yes | Your Supabase project URL |
| `SUPABASE_KEY` | Yes | Your Supabase anon/public key |
| `ANTHROPIC_API_KEY` | No | Claude API key (falls back to demo mode) |

### Streamlit Configuration

Edit `.streamlit/config.toml` to customize:
- Theme colors
- Upload size limits
- Server settings

## 🎨 Features Explained

### Color-Coded System

- **🟢 Green Glow** - Sustainable products (recyclable, biodegradable, eco-friendly)
- **🔴 Red Glow** - Not sustainable (plastic, synthetic, non-recyclable)
- **Animated Cards** - Smooth fade-in animations for results

### Sustainability Criteria

The AI analyzes products based on:
- ♻️ Material composition (recyclable, biodegradable)
- 🌍 Environmental impact
- 💪 Durability and lifecycle
- 🏭 Production process
- 🔄 End-of-life disposal options

## 🐛 Troubleshooting

### "Cannot connect to database"
- Check your Supabase credentials in secrets/`.env`
- Verify the database table was created correctly
- Check RLS policies are enabled

### "API Error"
- Verify ANTHROPIC_API_KEY is set (if using real API)
- Check API key permissions
- App works in demo mode without API key

### "Upload failed"
- Image must be under 5MB
- Supported formats: PNG, JPG, JPEG, WEBP
- Try compressing the image

### Mobile access not working
- Ensure both devices are on same Wi-Fi
- Check firewall settings on computer
- Try using `0.0.0.0` as server address

## 📊 Database Schema

```sql
Table: scans
- id (UUID, Primary Key)
- timestamp (Timestamp)
- objects_detected (JSONB)
- total_objects (Integer)
- sustainable_count (Integer)
- unsustainable_count (Integer)
- sustainability_score (Integer)
- overall_sustainable (Boolean)
- created_at (Timestamp)
```

## 🚀 Deployment Options

### Streamlit Cloud (Recommended - FREE!)
- Free hosting
- Auto-deploys from GitHub
- Custom domain support
- Easy secrets management

### Heroku
```bash
heroku create your-app-name
git push heroku main
```

### Railway
1. Connect GitHub repo
2. Add environment variables
3. Deploy!

### Google Cloud Run
```bash
gcloud run deploy
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📝 License

MIT License

## 🙏 Acknowledgments

- **Streamlit** - Amazing Python web framework
- **Anthropic Claude** - AI-powered image analysis
- **Supabase** - Backend database and storage
- **TailwindCSS** - Styling inspiration

## 📧 Support

Having issues? Please:
1. Check the troubleshooting section above
2. Review closed issues on GitHub
3. Open a new issue with details

---

<div align="center">
  
Made with ❤️ and 🌱 for a sustainable future

⭐ Star this repo if you find it helpful!

</div>
